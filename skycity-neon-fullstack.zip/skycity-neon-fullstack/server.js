const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, "data", "leaderboard.json");

app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

function readScores() {
  try {
    const data = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}
function writeScores(scores) {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  fs.writeFileSync(DATA_FILE, JSON.stringify(scores, null, 2));
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "SkyCity Neon API" });
});

app.get("/api/leaderboard", (_req, res) => {
  const scores = readScores().sort((a, b) => b.score - a.score).slice(0, 10);
  res.json({ scores });
});

app.post("/api/score", (req, res) => {
  const name = String(req.body?.name || "").trim().replace(/[<>]/g, "").slice(0, 18);
  const score = Number(req.body?.score);
  const rings = Number(req.body?.rings);
  const distance = Number(req.body?.distance);

  if (!name || !Number.isFinite(score) || score < 0 || score > 10000000 ||
      !Number.isFinite(rings) || rings < 0 || rings > 100000 ||
      !Number.isFinite(distance) || distance < 0 || distance > 10000000) {
    return res.status(400).json({ error: "Ma'lumotlar noto'g'ri." });
  }

  const scores = readScores();
  scores.push({
    name,
    score: Math.floor(score),
    rings: Math.floor(rings),
    distance: Math.floor(distance),
    date: new Date().toISOString()
  });
  scores.sort((a, b) => b.score - a.score);
  writeScores(scores.slice(0, 100));
  res.status(201).json({ ok: true, message: "Natija saqlandi." });
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`SkyCity Neon ishga tushdi: http://localhost:${PORT}`);
});
