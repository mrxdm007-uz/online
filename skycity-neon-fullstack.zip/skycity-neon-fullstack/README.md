# SkyCity Neon — Full-stack Drone Arcade

## Talablar
- Node.js 18 yoki undan yangi
- Internet faqat Google Fonts yuklanishi uchun kerak; o'yinning o'zi lokal ishlaydi.

## Ishga tushirish
1. ZIP faylni oching.
2. Papkada terminal oching.
3. `npm install`
4. `npm start`
5. Brauzerda `http://localhost:3000` manzilini oching.

## Loyihaning tuzilishi
- `server.js` — Express backend va REST API
- `public/index.html` — interfeys
- `public/style.css` — neon dizayn
- `public/game.js` — o'yin logikasi
- `data/leaderboard.json` — reyting ma'lumotlari

## API
- `GET /api/health` — server holati
- `GET /api/leaderboard` — TOP-10 natijalar
- `POST /api/score` — natijani saqlash (`name`, `score`, `rings`, `distance`)

Reyting lokal JSON faylida saqlanadi. Bu demo/arcade loyiha; ommaviy internetga joylashdan oldin autentifikatsiya, rate-limit va ma'lumotlar bazasini qo'shish tavsiya etiladi.
