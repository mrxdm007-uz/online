(() => {
const canvas=document.getElementById("world"),ctx=canvas.getContext("2d");
const $=id=>document.getElementById(id);
let W,H,dpr,keys={},mouse={x:0,y:0,active:false},running=false,ended=false;
let drone,buildings=[],rings=[],score=0,collected=0,battery=100,last=0,flightDistance=0,soundOn=false;
const WORLD=1700;
function resize(){dpr=Math.min(devicePixelRatio||1,2);W=innerWidth;H=innerHeight;canvas.width=W*dpr;canvas.height=H*dpr;canvas.style.width=W+"px";canvas.style.height=H+"px";ctx.setTransform(dpr,0,0,dpr,0,0)}
addEventListener("resize",resize);resize();
addEventListener("keydown",e=>{keys[e.key.toLowerCase()]=true;if([" ","arrowup","arrowdown","arrowleft","arrowright"].includes(e.key.toLowerCase()))e.preventDefault();if(e.key==="Enter"&&!running)start()});
addEventListener("keyup",e=>keys[e.key.toLowerCase()]=false);
canvas.addEventListener("mousemove",e=>{mouse.x=e.clientX;mouse.y=e.clientY;mouse.active=true});
$("startBtn").onclick=start;$("resetBtn").onclick=reset;$("closeModal").onclick=()=>$("resultModal").classList.remove("show");
$("refreshBtn").onclick=loadLeaderboard;
$("saveBtn").onclick=saveScore;
$("soundBtn").onclick=()=>{soundOn=!soundOn;$("soundBtn").textContent=soundOn?"♫":"♪";$("soundBtn").style.color=soundOn?"#55f6ff":"#8ba2b8"};
function reset(){
 drone={x:0,y:0,z:28,vx:0,vy:0,heading:0,tilt:0};
 buildings=[];rings=[];score=0;collected=0;battery=100;flightDistance=0;running=false;ended=false;
 for(let gx=-5;gx<=5;gx++)for(let gy=-5;gy<=5;gy++){
   if(gx%2===0&&gy%2===0){let h=35+((Math.abs(gx*17+gy*31)*13)%105);
    buildings.push({x:gx*190+47,y:gy*190+47,w:72+(Math.abs(gx*9+gy*7)%34),d:72+(Math.abs(gx*5-gy*11)%34),h,color:["#123b59","#193d64","#26345e","#15515b"][Math.abs(gx+gy)%4]});}
 }
 for(let i=0;i<8;i++){let a=i*.82+1.0;let radius=270+(i%3)*90;rings.push({x:Math.sin(a)*radius,y:-Math.cos(a)*radius,z:40+(i%4)*17,got:false});}
 updateHud();$("flightMode").textContent="STANDBY";$("missionText").textContent="HALQALARNI YIG‘ING";$("startBtn").innerHTML="<span>▶</span> PARVOZNI BOSHLASH";$("resultModal").classList.remove("show");
}
function start(){if(ended)reset();running=true;$("flightMode").textContent="ACTIVE";$("startBtn").innerHTML="PARVOZ DAVOM ETMOQDA";$("missionText").textContent="HALQALARGA YAQINLASHING"}
function endFlight(reason){if(ended)return;running=false;ended=true;$("flightMode").textContent="COMPLETE";$("resultText").textContent=reason;$("finalScore").textContent=score;$("finalRings").textContent=collected;$("saveStatus").textContent="";$("resultModal").classList.add("show")}
function project(x,y,z){
 const c=Math.cos(drone.heading),s=Math.sin(drone.heading),dx=x-drone.x,dy=y-drone.y;
 const rx=dx*c+dy*s,ry=-dx*s+dy*c,sc=560/(ry+560);
 return{x:W/2+rx*sc,y:H*.54+(z-drone.z)*sc-ry*.43*sc,sc,depth:ry};
}
function polygon(pts,fill,stroke){ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.stroke()}}
function ground(){
 ctx.fillStyle="#091b2a";ctx.fillRect(0,0,W,H);
 // distant skyline glow
 let g=ctx.createRadialGradient(W/2,H*.55,20,W/2,H*.55,Math.max(W,H)*.75);g.addColorStop(0,"#163c54");g.addColorStop(1,"#07101d");ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
 for(let i=-11;i<=11;i++){
  let p=project(i*190,-WORLD,0),q=project(i*190,WORLD,0),r=project(-WORLD,i*190,0),s=project(WORLD,i*190,0);
  ctx.strokeStyle=i%2===0?"#37e9fa35":"#4b85ae1b";ctx.lineWidth=i%2===0?2:1;
  ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(q.x,q.y);ctx.moveTo(r.x,r.y);ctx.lineTo(s.x,s.y);ctx.stroke();
 }
 // luminous road edges
 for(let i=-10;i<=10;i+=2){let a=project(i*190-32,-WORLD,0),b=project(i*190-32,WORLD,0),c=project(i*190+32,-WORLD,0),d=project(i*190+32,WORLD,0);ctx.strokeStyle="#51dfff18";ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.moveTo(c.x,c.y);ctx.lineTo(d.x,d.y);ctx.stroke()}
}
function buildingsDraw(){
 const list=buildings.map(b=>({b,p:project(b.x+b.w/2,b.y+b.d/2,0)})).sort((a,b)=>b.p.depth-a.p.depth);
 for(const {b} of list){
  let a=project(b.x,b.y,0),c=project(b.x+b.w,b.y,0),d=project(b.x+b.w,b.y+b.d,0),e=project(b.x,b.y+b.d,0);
  let A=project(b.x,b.y,b.h),C=project(b.x+b.w,b.y,b.h),D=project(b.x+b.w,b.y+b.d,b.h),E=project(b.x,b.y+b.d,b.h);
  if(Math.max(a.x,c.x,d.x,e.x)<-120||Math.min(a.x,c.x,d.x,e.x)>W+120)continue;
  polygon([a,c,C,A],"#0b3048","#35dfff55");polygon([c,d,D,C],"#0b243d","#2779a0aa");polygon([A,C,D,E],b.color,"#68eaffaa");
  // windows and rooftop light
  for(let j=1;j<=3;j++){let q=project(b.x+b.w*j/4,b.y,b.h*.58);ctx.fillStyle="#64efff";ctx.globalAlpha=.55;ctx.shadowColor="#37eaff";ctx.shadowBlur=8;ctx.fillRect(q.x-2,q.y-5,4,9);ctx.globalAlpha=1;ctx.shadowBlur=0}
  ctx.strokeStyle="#a4faff";ctx.globalAlpha=.35;ctx.beginPath();ctx.moveTo(A.x,A.y);ctx.lineTo(C.x,C.y);ctx.stroke();ctx.globalAlpha=1;
 }
}
function drawRings(){
 for(const r of rings){if(r.got)continue;let p=project(r.x,r.y,r.z);if(p.depth<-200||p.depth>950)continue;
  let radius=Math.max(5,27*p.sc);ctx.save();ctx.translate(p.x,p.y);ctx.strokeStyle="#5cfaff";ctx.lineWidth=3*p.sc;ctx.shadowColor="#4cf7ff";ctx.shadowBlur=24;ctx.beginPath();ctx.ellipse(0,0,radius,radius*.68,0,0,Math.PI*2);ctx.stroke();ctx.strokeStyle="#f45bff";ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(0,0,radius*.78,radius*.53,0,0,Math.PI*2);ctx.stroke();ctx.restore();
 }
}
function droneDraw(){
 ctx.save();ctx.translate(W/2,H*.54);ctx.rotate(drone.tilt*.22);ctx.shadowColor="#55f6ff";ctx.shadowBlur=20;
 ctx.strokeStyle="#c5fbff";ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-27,-15);ctx.lineTo(27,15);ctx.moveTo(27,-15);ctx.lineTo(-27,15);ctx.stroke();
 ctx.fillStyle="#54efff";ctx.beginPath();ctx.roundRect(-11,-8,22,16,5);ctx.fill();ctx.fillStyle="#f8ffff";
 for(let [x,y] of [[-28,-16],[28,-16],[-28,16],[28,16]]){ctx.beginPath();ctx.arc(x,y,5,0,Math.PI*2);ctx.fill()}
 ctx.restore();
}
function collision(){for(let b of buildings)if(drone.x>b.x-12&&drone.x<b.x+b.w+12&&drone.y>b.y-12&&drone.y<b.y+b.d+12&&drone.z<b.h+9)return true;return false}
function update(dt){
 if(!running)return;
 let forward=(keys.w?1:0)-(keys.s?1:0),side=(keys.d?1:0)-(keys.a?1:0),boost=keys.shift?1.75:1;
 if(keys.arrowleft)drone.heading-=1.7*dt;if(keys.arrowright)drone.heading+=1.7*dt;
 if(mouse.active){let dx=mouse.x-W/2;drone.heading+=Math.max(-1,Math.min(1,dx/(W*.45)))*.75*dt}
 let accel=220*boost;
 drone.vx+=(Math.sin(drone.heading)*forward+Math.cos(drone.heading)*side)*accel*dt;
 drone.vy+=(-Math.cos(drone.heading)*forward+Math.sin(drone.heading)*side)*accel*dt;
 let drag=Math.pow(.92,dt*60);drone.vx*=drag;drone.vy*=drag;
 let max=keys.shift?245:145,speed=Math.hypot(drone.vx,drone.vy);if(speed>max){drone.vx*=max/speed;drone.vy*=max/speed}
 drone.x+=drone.vx*dt;drone.y+=drone.vy*dt;flightDistance+=speed*dt;
 if(keys.e)drone.z=Math.min(150,drone.z+45*dt);if(keys.q)drone.z=Math.max(8,drone.z-45*dt);
 drone.tilt=Math.max(-1,Math.min(1,side*.7));battery=Math.max(0,battery-(keys.shift?.9:.22)*dt);
 for(let r of rings)if(!r.got&&Math.hypot(drone.x-r.x,drone.y-r.y)<45&&Math.abs(drone.z-r.z)<24){r.got=true;collected++;score+=250+Math.round(speed);$("missionText").textContent=collected>=8?"MISSIYA BAJARILDI":"KEYINGI HALQANI TOPING"}
 if(collision()){endFlight("Dron bino bilan to‘qnashdi. Yana bir bor urinib ko‘ring.");return}
 if(battery<=0){endFlight("Batareya quvvati tugadi.");return}
 if(collected>=8){score+=500;endFlight("Ajoyib! Barcha 8 ta neon halqani yig‘dingiz.");return}
 updateHud();
}
function updateHud(){
 $("rings").innerHTML=collected+' <i>/ 8</i>';$("score").textContent=String(score).padStart(5,"0");$("alt").textContent=Math.round(drone.z);$("speed").textContent=Math.round(Math.hypot(drone.vx,drone.vy)*.9);$("battery").textContent=Math.round(battery);$("batteryBar").style.width=battery+"%";$("progressBar").style.width=(collected/8*100)+"%";
}
function frame(t){let dt=Math.min((t-last)/1000||0,.04);last=t;update(dt);ground();drawRings();buildingsDraw();droneDraw();requestAnimationFrame(frame)}
async function loadLeaderboard(){
 try{let r=await fetch("/api/leaderboard");if(!r.ok)throw Error();let data=await r.json();let list=$("leaderList");list.innerHTML="";
  if(!data.scores.length){list.innerHTML='<li class="empty">Hozircha rekord yo‘q — birinchi bo‘ling!</li>';return}
  data.scores.slice(0,7).forEach(s=>{let li=document.createElement("li"),name=document.createElement("span"),pts=document.createElement("strong");name.textContent=s.name;pts.className="pts";pts.textContent=Number(s.score).toLocaleString("uz-UZ");li.append(name,pts);list.append(li)});
 }catch{$("leaderList").innerHTML='<li class="empty">Server bilan aloqa yo‘q</li>'}
}
async function saveScore(){
 let name=$("pilotName").value.trim();if(!name){$("saveStatus").textContent="Nicknameni kiriting.";return}
 $("saveBtn").disabled=true;$("saveStatus").textContent="Saqlanmoqda...";
 try{let r=await fetch("/api/score",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name,score,rings:collected,distance:Math.round(flightDistance)})});let data=await r.json();if(!r.ok)throw Error(data.error||"Saqlash amalga oshmadi");$("saveStatus").textContent="✓ Natija saqlandi!";loadLeaderboard()}
 catch(e){$("saveStatus").textContent="Xatolik: "+e.message}
 finally{$("saveBtn").disabled=false}
}
async function health(){try{let r=await fetch("/api/health");if(!r.ok)throw Error();$("apiStatus").textContent="BACKEND ONLINE"}catch{$("apiStatus").textContent="BACKEND OFFLINE"}}
reset();health();loadLeaderboard();requestAnimationFrame(frame);
})();